const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/exam1', {useNewUrlParser: true, useUnifiedTopology:true});
