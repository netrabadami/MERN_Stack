import React,{useState, useEffect} from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

const ProductList = props =>{
    const [products, setProducts] = useState([]);

    useEffect(() =>{
        axios.get("http://localhost:8000/api/products")
        .then(res => {
            setProducts(res.data);
            
        })
        .catch(err => console.log(err));
    })
    
    return(
        <div className="container">
            
            <h1>Products Info</h1>
           
            <table border="1px solid black" className="table table-dark">
            <tbody>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Description</th>
                    
                </tr>
                
                {
                    products.map((product, i) =>
                        <tr key={i}>
                            <td><Link to={"/info/" + product._id}>{product.title}</Link></td>
                            <td>${product.price}</td>
                            <td>{product.description}</td>
                          
                        </tr>
                    )
                }
            </tbody>
            </table>
        </div>
    )

//End of File
}

export default ProductList;