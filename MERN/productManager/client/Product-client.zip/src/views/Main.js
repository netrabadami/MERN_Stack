import React, {useState, useEffect} from 'react';
import axios from 'axios';
import ProductForm from '../components/ProductForm';
export default () =>{
    const [product, setproduct] = useState([]);


    return(
        <ProductForm />
    )

 //End of file   
}

