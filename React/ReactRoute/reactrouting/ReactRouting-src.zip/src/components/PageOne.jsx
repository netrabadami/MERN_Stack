import React from 'react';
import '../bootstrap.css';
import '../style.css'

const PageOne = props => {

    return(
        <div className="container">
            <h1>WELCOME</h1>
        </div>
    )
}

export default PageOne;