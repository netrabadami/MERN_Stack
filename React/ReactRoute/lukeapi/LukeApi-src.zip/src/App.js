import React from 'react';
import logo from './logo.svg';
import './App.css';
import LukeApi from './components/LukeApi';

function App() {
  return (
    <div className="App">
        <LukeApi />
    </div>
  );
}

export default App;
