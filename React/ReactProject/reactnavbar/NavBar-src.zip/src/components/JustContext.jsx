import { createContext } from 'react';

const JustContext = createContext();

export default JustContext;