import React,{useState} from 'react';
import Input from './Input'

const FormWrapper = props =>{
    return(
        <div>
            <Input />
        </div>
    )
//End of file    
}

export default FormWrapper;